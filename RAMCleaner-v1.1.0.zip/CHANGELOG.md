# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-08-18

### Added
- **RAM Usage Display**: Shows before/after RAM statistics including total, used, free memory and freed amount.
- **Windows Temp Cleanup**: Now cleans both `%TEMP%` and `C:\Windows\Temp` directories (previously only user temp was cleaned).
- **Cleanup Reporting**: Displays number of cleaned files and disk space freed after temp cleanup.
- **Error Reporting**: All operations now show clear error messages instead of silently failing.
- **NT API Result Checking**: `NtSetSystemInformation` return values are now checked and reported.
- **Privilege Status Feedback**: Reports if privilege elevation was successful.
- **Project Analysis Report**: Added `ANALIZ_2026-08-18.md` with comprehensive analysis and improvement tracking.
- **Version Display**: Version number shown in title bar and ASCII art header.

### Fixed
- **Windows Temp Not Cleaned**: The README and console menu promised `C:\Windows\Temp` cleaning but code only cleaned user temp. Now both are cleaned.
- **Silent Error Handling**: Empty `catch {}` blocks now properly report errors to the user.
- **Clipboard Clearing**: Replaced fragile `cmd /c "echo off | clip"` pipe with native `Set-Clipboard -Value $null` with fallback.
- **Progress Bar Speed**: Reduced animation delay from 40ms to 20ms per character (20% faster).
- **CreateDesktopShortcut.bat**: Replaced `ping -n 3 127.0.0.1` delay with proper `timeout /t 3`.
- **RAM_Temizle.bat**: Added startup message, admin status confirmation, and proper window close delay.

### Changed
- **Progress Bar Visual**: Upgraded from `[====================]` to Unicode block characters `[█████████████████████████]` for modern appearance.
- **Menu Icons**: Added emoji icons to menu items for better visual distinction.
- **Console Output**: Improved formatting with box-drawing characters and better spacing.
- **Post-Cleanup Message**: Now shows different messages for success vs partial failure.

### Improved
- **Temp Cleanup Safety**: Uses `-ErrorAction SilentlyContinue` for locked files, preventing mid-cleanup crashes.
- **Add-Type Error Handling**: Font manager and MemoryCleaner loading failures now show warnings instead of silent failures.
- **Memory Management**: Better RAM info retrieval using `Get-CimInstance` for cross-version compatibility.

---

## [1.0.0] - 2026-08-04

### Added
- Native Windows Standby Memory and Modified Page List purging via `ntdll.dll` API `NtSetSystemInformation`.
- Automatic Windows UAC elevation handling in `RAM_Temizle.bat`.
- Interactive PowerShell console UI featuring step-by-step execution and real-time progress bars (`ClearMemory.ps1`).
- Automatic font height override to 16pt Bold Consolas via Win32 API (`SetCurrentConsoleFontEx`) and Console Registry overrides.
- DNS Cache flushing (`ipconfig /flushdns`), temporary files cleanup (`%TEMP%`, `C:\Windows\Temp`), and clipboard clearing.
- Desktop shortcut creation helper script (`CreateDesktopShortcut.bat`).
- Developer attribution and repository link display in the console header.
